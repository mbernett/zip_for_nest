#!/bin/bash
#PBS -l select=1:ncpus=16:ngpus=1
#PBS -l walltime=24:00:00
#PBS -j oe
#PBS -N job_name
#PBS -q gpu

cd $PBS_O_WORKDIR
module load gcc-12.2.1/gromacs-2023_plumed-2.9.0

gmx_mpi mdrun -deffnm steered -plumed plumed_input_steered.dat -maxh 24


